/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

import { btoa } from '../../util.ts';

export { ArtilleryInspectScriptPlugin as Plugin };

function ArtilleryInspectScriptPlugin(
  this: { script: Record<string, any>; events: unknown },
  script: Record<string, any>,
  events: unknown
) {
  this.script = script;
  this.events = events;

  const checksConfig = script.config?.ensure || script.config?.plugins?.ensure;

  if (checksConfig) {
    console.log(
      `inspect-script.config.ensure=${btoa(JSON.stringify(checksConfig))}`
    );
  }

  return this;
}
ArtilleryInspectScriptPlugin.prototype.cleanup = (
  done: (err: Error | null) => void
) => {
  done(null);
};
